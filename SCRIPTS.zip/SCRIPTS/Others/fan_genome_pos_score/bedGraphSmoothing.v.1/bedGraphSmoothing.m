% This script is to smoothen values (column 4th) in bedGraph file.
% 

clear
smoothspan = 101;  % Set span (nts) of smoothing window (odd).
smoothmethod = 'moving'; % Set smoothing method.Optional:'moving','lowess','loess','sgolay','rlowess','rloess'.

%% bedGraph file import.
% dos('copy y147N_8mer_FC2.bedGraph temp.txt');   % Create a temporary txt file for function 'readtable'.
unix('cp 94N_8mer_chr8_all.bedGraph 94N_8mer_chr8_all.txt');
tabData = readtable('94N_8mer_chr8_all.txt','Delimiter','\t','ReadVariableNames',0);  % Import data from the temporary txt file.
% dos('del temp.txt');    % Delete the temporary txt file.
unix('rm 94N_8mer_chr8_all.txt');

%% Divide to different chromosomes for individual smoothing.
chrName = unique(tabData.Var1);
for i=1:length(chrName)
    cellChr{i,1} =  tabData(strcmp(tabData.Var1, chrName(i)),:);
end
clear tabData;  % Clear the undivided data for saving memory.

%% Smoothing.
tabResu = [];
for i=1:length(cellChr)
    smoothed{i,1} = smooth(table2array(cellChr{i,1}(:,2)), table2array(cellChr{i,1}(:,4)), smoothspan, smoothmethod); % Smoothen the data.
    cellChr{i,1}(:,4) = array2table(smoothed{i,1});   % Replace values by the smoothed ones.
    tabResu  = [tabResu; cellChr{i,1}];
end

%% Export results to a bedGraph file.
writetable(tabResu, '94N_8mer_chr8_all_m101.txt', 'Delimiter', '\t', 'WriteVariableNames', 0);    % Write results to a txt file.
% dos('ren Resu.txt Resu.bedGraph');  % Rename the txt file into a bedGraph file.
unix('mv 94N_8mer_chr8_all_m101.txt  94N_8mer_chr8_all_m101.bedGraph');