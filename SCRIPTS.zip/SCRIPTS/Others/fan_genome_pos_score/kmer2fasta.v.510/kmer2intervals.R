#!/usr/bin/r
# kmer2intervals v.510 by Fan Zhong.
# The kmer list from a text file should be with sequences in the col. 1 and scores in the col. 2.
# The genomic regions should be from a FASTA file.
# This script can map kmer list with redundant scores than previous versions.

rm(list = ls())
library(Biostrings)
setwd ("/home/fan/Desktop/NucleosomeMotifMap")  # set work directory.

# Load genomic regions from a FASTA file ------------------------------
chr <- readDNAStringSet("/home/fan/DHS/DHS_mouse_tissues/1k/forkmer/mLiver_rcn3_ef2k.fa", format = "fasta", nrec = -1L, skip = 0L, seek.first.rec = FALSE, use.names = TRUE)
chr_rc <- reverseComplement(chr)

# Load kmer list with scores ------------------------------
kmerTab <- read.table(file = "/home/fan/Desktop/NucleosomeMotifMap/Beikmers/cycle4_liver_sig_10mer_u_cmp_cycle1_liver_sig_10mer_u.txt",
                      skip = 1, header = FALSE, sep = "\t", colClasses = c("character", "numeric", "NULL", "NULL", "NULL", "NULL"))
kmerSet <- DNAStringSet(x = t(kmerTab[1]))
kmerTab[3] <- seq(nrow(kmerTab))
names(kmerSet) <- paste(t(kmerTab[2]), "A", t(kmerTab[3]), sep = "")  # To eliminate redundant kmer "names" by tagging ordinal numbers.
k <- nchar(kmerTab[1,1])
kmerPDict <- PDict(kmerSet, max.mismatch = NA, tb.start = NA, tb.end = NA, tb.width = NA, algorithm = "ACtree2", skip.invalid.patterns = FALSE)
c <- NULL

for (j in 1:length(chr))
{
  kmerMatch <- matchPDict(kmerPDict, chr[[j]], max.mismatch = 0, min.mismatch = 0, with.indels = FALSE, fixed = TRUE, algorithm = "auto", verbose = FALSE)
  kmerMatch_rc <- matchPDict(kmerPDict, chr_rc[[j]], max.mismatch = 0, min.mismatch = 0, with.indels = FALSE, fixed = TRUE, algorithm = "auto", verbose = FALSE)
  chr.name <- names(chr[j])
  chr.length <- length(chr[[j]])
  
  a <- data.frame(unlist(kmerMatch))
  a$strand <- "+"
  a$chr <- chr.name
  
  b <- data.frame(unlist(kmerMatch_rc))
  b$start.new <- chr.length + 1 - b$end
  b$end.new <- chr.length + 1 - b$start
  b$strand <- "-"
  b$start <- b$start.new
  b$end <- b$end.new
  b$start.new <- NULL
  b$end.new <- NULL
  b$chr <- chr.name
  
  c <- rbind(a, b, c)
}

c$width <- NULL
c <- c[c(5, 1:4)]
c <- c[order(c$chr, c$start), ]
c$names <- sub("A.*", "", c$names)  # To remove ordinal number tags.
c$chr <- sub("-", ":", c$chr)
write.table(c, paste("liver1k_BW", k, "mer.bed", sep = ""), quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)