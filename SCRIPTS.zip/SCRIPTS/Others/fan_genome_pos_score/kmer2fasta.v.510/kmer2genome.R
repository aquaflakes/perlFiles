#!/usr/bin/r
# kmer2genome v.510 by Fan Zhong.
# The kmer list from a text file should be with sequences in the col. 1 and scores in the col. 2.
# Each chromosome should be from one FASTA file, and all FASTA files should be in the same directory.
# This script can map kmer list with redundant scores than previous versions.

rm(list = ls())
gc()
library(Biostrings)
setwd("/home/fan/Desktop/NucleosomeMotifMap")  # set work directory.

# Load kmer list with scores ============================
kmerTab <- read.table(file = "/home/fan/Desktop/NucleosomeMotifMap/freq_cmp_bk.pl_pseudo20/94N_bound_cyc4_10mer_cmp_94N_unbound_cyc4_10mer.txt",
                      skip = 1, header = FALSE, sep = "\t", colClasses = c("character", "numeric", "NULL", "NULL", "NULL", "NULL"))  # Input the kmer list here.
kmerSet <- DNAStringSet(x = t(kmerTab[1]))
kmerTab[3] <- seq(nrow(kmerTab))
names(kmerSet) <- paste(t(kmerTab[2]), "A", t(kmerTab[3]), sep = "")  # To eliminate redundant kmer "names" by tagging ordinal numbers.
k = nchar(kmerTab[1, 1])
kmerPDict <- PDict(kmerSet, max.mismatch = NA, tb.start = NA, tb.end = NA, tb.width = NA, algorithm = "ACtree2", skip.invalid.patterns = FALSE)
rm(kmerTab, kmerSet)
gc()

chrdir <- "/home/fan/Database/hg19_chr_fa_simple/"  # Input the genome database file here.
chrfile <- list.files(chrdir)
chrdirfile <- paste(chrdir, chrfile, sep = "")
ndir <- length(chrdirfile)

for (i in 1:ndir) {
  # Load chromosome from a FASTA file ============================
  chr <- readDNAStringSet(chrdirfile[i] , format = "fasta", nrec = -1L, skip = 0L, seek.first.rec = FALSE, use.names = TRUE)
  chr_rc <- reverseComplement(chr)
  chr.name <- names(chr)
  chr.length <- length(chr[[1]])
  
  # Kmers match to chromosome ============================
  kmerMatch <- matchPDict(kmerPDict, chr[[1]], max.mismatch = 0, min.mismatch = 0, with.indels = FALSE, fixed = TRUE, algorithm = "auto", verbose = FALSE)
  kmerMatch_rc <- matchPDict(kmerPDict, chr_rc[[1]], max.mismatch = 0, min.mismatch = 0, with.indels = FALSE, fixed = TRUE, algorithm = "auto", verbose = FALSE)
  rm(chr, chr_rc)
  gc()
  
  a <- data.frame(unlist(kmerMatch))
  rm(kmerMatch)
  gc()
  a$strand <- "+"
  
  b <- data.frame(unlist(kmerMatch_rc))
  rm(kmerMatch_rc)
  gc()
  b$start.new <- chr.length + 1 - b$end
  b$end.new <- chr.length + 1 - b$start
  b$strand <- "-"
  b$start <- b$start.new
  b$end <- b$end.new
  b$start.new <- NULL
  b$end.new <- NULL
  
  a <- rbind(a, b)
  rm(b)
  gc()
  a$width <- NULL
  a$chr <- chr.name
  a <- a[c(5, 1:4)]
  a <- a[order(a$start), ]
  a$names <- sub("A.*", "", a$names)  # To remove ordinal number tags.
  write.table(a, paste(chr.name, k, "mer.bed", sep = "_"), quote = FALSE, sep = "\t", row.names = FALSE, col.names = FALSE)  
}
