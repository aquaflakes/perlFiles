#!/usr/bin/perl -w
# to do motif mapping for FJ4.4CAP selex with DBD
# count at the center (odd) or center 2 bp (even) of motif

use warnings;
use strict;
use Data::Dumper;
use Getopt::Long;
use File::Basename;
#use Me::Nu_cnt::checkfile;
#use POSIX qw(ceil strftime);
use File::Spec qw(rel2abs);

use Bio::Perl;
use Bio::Seq;
use Me::MotifMap::CntArray;
use Mylib1::seqFile;
use MOODS; use MOODS::Tools qw(printResults numResults readMatrix);

		
######### global variables to adjust #############
our @allGuides= ("/var/www/kaz/guide/all-human-version4.txt" ,
				 "/var/www/kaz/guide/Human_IndividualTF_Cell_eLife_Nature_YimengsMethPaper.txt",
				 "/var/www/kaz/guide/MethylSELEX_v0.7_FinalCall_without_fail.txt",
				 "/var/www/kaz/guide/Methylation_SELEX_Version_0.5.txt"
			  );
######### usage
my $this_programme = basename($0);
my $cmdInput=$this_programme." ".join(" ", @ARGV);
my $usage = "\n\$$this_programme -f '*.txt' -o outDir -u\n
	***general***
	-f      files to process
	-o      output path
	-t      threads
	-h      help
	
	***specific***
	-p      p value for Moods
	-l      lines to process per file
	-u      remove duplicated reads
	";

########## Info from cmd line #################
	##### options
	GetOptions ('f=s' => \my $files, 't=i' => \my $threads, 'o=s' => \my $outputPath, 'p=f' => \my $p_value, 'l=i' => \my $lines_to_process, 'h' => \my $helpInfo, 'u' => \my $rmdup); # i:int   f:float   s:string    // 'm=s' => \my $matrices
	if ($helpInfo||(!$files)) { print "\nusage: $usage\n";exit;}

	# set default value
	$outputPath||="./$this_programme";
	$threads||=15;
	$p_value||=0.0001;

	#output cmd info
	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
    qx(rm -r $outputPath) if (-d $outputPath);    qx(mkdir -p $outputPath); qx(mkdir -p $outputPath/perlcmd/);
    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd
		
	# packing param
	my @files=glob($files);	chomp @files;
	my @param; for (0..$#files){ push @param, [$files[$_]];} 
	

# -----------
use Mylib1::Parallel::file;
&file::mProcess($threads,\&singleProc,\@param); # using mThread necessary for debug !!
#&file::mThread($threads,\&singleProc,\@param);

chdir $outputPath;
system ('Rscript /wrk/data/fangjie/lib/Rlib/MotifMapPlot.R');
system ("convert -quality 95 ./PNG/* ./TFMotifMap_p_$p_value.pdf");

exit;

# *** multi proc ***
sub singleProc  
{
	my $param_Aref = shift;
	my ($file)= @$param_Aref;
	
	my @allreads; use Mylib1::seqFile; &seqFile::getallSeq(\@allreads,$file,$lines_to_process);
	&seqFile::rmdup_3point(\@allreads) if $rmdup;
	my $combinedReads=join "",@allreads;
	
	    # figure out ligand length and cut_value for each PWM
    my $liglength= length $allreads[10]; print "length of the reads is $liglength bp for $file \n";
	my $totalReads=@allreads;
	
	#----------- parse the file name to find out TF name and wells -------------
	$file =~ m/TF.*-(?=[^\d]{1})(.{1,15})IIIc/; my $TFname=$1; my $TFnoNum=$TFname=~s/[0-9\-L]*$//ir;
	$file =~ m/-([A-P]{1}\d{1,2})-/; my $well=$1;   #(?=[^\d]{1}) to make extration like TF105-NKX2-4IIIc correct
	$well=~ s/([A-P])0(\d)/$1$2/;  # to change A01 into A1 for SELEX
	
	#----------- find out pfm file to use from TF name -----
	my @matrix_files; my @matrix_Names; 
	&pfmFromGuide($_,$TFname, \@matrix_files, \@matrix_Names) for @allGuides; # first the exact hit
	&pfmFromGuide($_,$TFnoNum, \@matrix_files, \@matrix_Names) for @allGuides; # then everything related
	
	if ($#matrix_files>19) {splice(@matrix_files,19,-1) ;splice(@matrix_Names,19,-1); } # cannot plot too many
	if ($#matrix_files== -1) {print "\n!!!!!!!!!!!!!!\n!!!!!!!!!\nno PWM found for $file\n\n"; return;}; # do not calc if no matrix found
	
	push @matrix_Names, "r_".$matrix_Names[$_] for (0..$#matrix_Names); #construct names for reverse
	my $Num_of_Matrix=scalar(@matrix_files);
	my (@matrices, @rc_matrices, @r_matrices, @c_matrices, @all_matrices,          @Motif_L_of_matrices, @thresholds);
	for (my $i=0;$i<$Num_of_Matrix;$i++)
	{
		$matrices[$i] = readMatrix($matrix_files[$i]);
		$matrices[$i] = MOODS::Tools::reverseComplement($matrices[$i]); # !!!!!! rc !!!
		my @c_tmp = reverse (@{$matrices[$i]});
		$c_matrices[$i] = \@c_tmp;
	
		$rc_matrices[$i] = MOODS::Tools::reverseComplement($matrices[$i]);
		my @r_tmp = reverse (@{$rc_matrices[$i]});
		$r_matrices[$i] = \@r_tmp;
	
		$Motif_L_of_matrices[$i] = scalar(@{$matrices[$i][0]});
	}
                    #signal       #control
	@all_matrices = (@matrices,  @r_matrices); #join all matrices together to get faster mapping,   //@rc_matrices, @c_matrices not used here, pay attention to MapSR indices of @{$results[$i+$Num_of_Matrix]}
	@thresholds= (($p_value) x scalar(@all_matrices)); #()surronding p_value is important, ######## specify p value
	
    my @cut_values;
    for (my $i=0; $i<$Num_of_Matrix;$i++) {$cut_values[$i] = $liglength-$Motif_L_of_matrices[$i]+1;}    
    
    
    #creat N countArrayRef and initialize with 0 for different PWMs
    my $countArrayRef;
    for (my $i=0; $i<$Num_of_Matrix;$i++)  { for (my $j=0; $j<$liglength; $j++) {$countArrayRef->[$i]->[$j]=0;$countArrayRef->[$i+$Num_of_Matrix]->[$j]=0};}
	&MapSR($countArrayRef,$combinedReads,$liglength,\@cut_values,\@all_matrices,\@thresholds,$Num_of_Matrix);
	&normalize($countArrayRef,$totalReads); # divide hits by totalReads
	
	use Mylib1::fileIO; my $outfilename=$well."_".&fileIO::getfile($file).'.txt';
	&CntArray::wtCountFile($countArrayRef,\@matrix_Names,$outputPath, $outfilename);
}


sub pfmFromGuide #extract pfm path from guide
{
	my ($guidefile, $search_string, $matrix_files_Aref,$matrix_Names_Aref)=@_;
	my $string= "cat $guidefile | grep -P -i '^$search_string\[\\d-L]*\\t' | "; #some TF name like HOXB2L2 NKD2-4
	$string.=q{perl -lne '@all=split /\t/; $pfm_key="$all[2]_$all[3]_$all[4]"; @allpfm= glob("/var/www/kaz/data/pfm/shortspacek/$pfm_key*.pfm"); chomp @allpfm; print "$all[0]_$all[3]_$all[4]_$all[7]_$all[8]"."\t".$allpfm[0] if @allpfm;'}; # some like TAGTTA40NGTG_XEPAQ_NNNNTGCTGAC
	my @matrix_info_tmp=`$string`; chomp @matrix_info_tmp;
	map {my @info=split/\t/; push @$matrix_Names_Aref, $info[0]; push @$matrix_files_Aref, $info[1];} @matrix_info_tmp;
}

sub MapSR
{
    my ($countArrayRef,$combinedReads,$liglength,$cut_values_Ref,$all_matrices_Aref,$thresholds_Aref,$Num_of_Matrix)=@_;  #liglength, @matrices, @Motif_L_of_matrices should be passed if not in the same file
	my @all_matrices = @$all_matrices_Aref;
	my @thresholds= @$thresholds_Aref;
	my $seq = Bio::Seq->new(-seq  => $combinedReads, -alphabet => 'dna' );

        ## We convert the count matrix into log-odds scores in base 2 logarithm and find hits scoring
        my @results = MOODS::search(-seq => $seq, -matrices => \@all_matrices,  -thresholds => \@thresholds, -threshold_from_p => 1 );

        #add SR count into countArrays of each PWM
        for (my $i=0; $i<$Num_of_Matrix;$i++)
        {
            #count mapping hits
            my @positions = do {my $j = 0; grep {!($j++ % 2)} @{$results[$i]}}; #extract only the position info but not scores for matrix[i]
            #my @positions_rc = do {my $j = 0; grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix]}}; 
            $countArrayRef->[$i]= &CntArray::addCnt_to_CntSt_combinedRead($countArrayRef->[$i],\@positions,$cut_values_Ref->[$i],$liglength);            
            #$countArrayRef->[$i]= &CntArray::addCnt_to_CntSt_combinedRead($countArrayRef->[$i],\@positions_rc,$cut_values_Ref->[$i],$liglength);
            
            #count ctrl hits
            #my @positions_c = do {my $j = 0; grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix*2]}}; #extract only the position info but not scores for matrix[i]
            #my @positions_r = do {my $j = 0; grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix*3]}};
			my @positions_r = do {my $j = 0; grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix]}}; 
            #$countArrayRef->[$i+$Num_of_Matrix]= &CntArray::addCnt_to_CntSt_combinedRead($countArrayRef->[$i+$Num_of_Matrix],\@positions_c,$cut_values_Ref->[$i],$liglength);            
            $countArrayRef->[$i+$Num_of_Matrix]= &CntArray::addCnt_to_CntSt_combinedRead($countArrayRef->[$i+$Num_of_Matrix],\@positions_r,$cut_values_Ref->[$i],$liglength);
        }
}

sub normalize
{
	my ($Aref,$totalReads)=@_;
	foreach (@$Aref)
	{
		if (ref($_)) {&normalize($_,$totalReads) } else{$_/=$totalReads};
	}
}