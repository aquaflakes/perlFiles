#!/usr/bin/perl -w
# to do motif mapping for FJ4.4CAP selex with DBD
# count at the center (odd) or center 2 bp (even) of motif

use warnings;
use strict;
use Data::Dumper;
use Getopt::Long;
use File::Basename;
#use Me::Nu_cnt::checkfile;
#use POSIX qw(ceil strftime);
use File::Spec qw(rel2abs);

use Bio::Perl;
use Bio::Seq;
use Me::MotifMap::CntArray;
use Mylib1::seqFile;
use MOODS; use MOODS::Tools qw(printResults numResults readMatrix);

my $test=0;
#my $cutoff=30; # only take ori or rc motif <$cutoff from end

		
######### global variables to adjust #############
our @allGuides= ("/var/www/kaz/guide/all-human-version4.txt" ,
				 "/var/www/kaz/guide/Human_IndividualTF_Cell_eLife_Nature_YimengsMethPaper.txt",
				 "/var/www/kaz/guide/MethylSELEX_v0.7_FinalCall_without_fail.txt",
				 "/var/www/kaz/guide/Methylation_SELEX_Version_0.5.txt"
			  );
######### usage
my $this_programme = basename($0);
my $cmdInput=$this_programme." ".join(" ", @ARGV);
my $usage = "\n\$$this_programme -f 'file' -u -t 20 -o relposMap/147c4

	***general***
	-f      files to process
	-o      output path
	-t      threads
	-h      help
	
	***specific***
	-p      p value for Moods
	-l      lines to process per file
	-u      remove duplicated reads
	";

########## Info from cmd line #################
	GetOptions ('f=s' => \my $files, 't=i' => \my $threads, 'o=s' => \my $outputPath, 'p=f' => \my $p_value, 'l=i' => \my $lines_to_process, 'h' => \my $helpInfo, 'u' => \my $rmdup); # i:int   f:float   s:string    // 'm=s' => \my $matrices
	if ($helpInfo||(!$files)) { print "\nusage: $usage\n";exit;}

	# set default value
	$outputPath||="./$this_programme";
	$threads||=15;
	$p_value||=0.0001; if ($test) {$p_value=0.00001;}
	

	#output cmd info
	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
    qx(rm -r $outputPath) if (-d $outputPath);    qx(mkdir -p $outputPath/data/); qx(mkdir -p $outputPath/perlcmd/);
    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd
		
	# packing param
	my @files=glob($files);	chomp @files;
	my @param; for (0..$#files){ push @param, [$files[$_]];} 
	

# -----------
use Mylib1::Parallel::file;
&file::mProcess($threads,\&singleProc,\@param); # using mThread necessary for debug !!
#&file::mThread($threads,\&singleProc,\@param);

chdir $outputPath;
system ('Rscript /wrk/data/fangjie/lib/Rlib/motifMap/MotifMapPlot_v2.R');
system ("convert -quality 95 ./PNG/* ./TFMotifMap_p_$p_value.pdf");

exit;

# *** multi proc ***
sub singleProc  
{
	my $param_Aref = shift;
	my ($file)= @$param_Aref;
	
	my @allreads; use Mylib1::seqFile; &seqFile::getallSeq(\@allreads,$file,$lines_to_process);
	&seqFile::rmdup_3point(\@allreads) if $rmdup;
	my $combinedReads=join "",@allreads;
	
	    # figure out ligand length and cut_value for each PWM
    my $liglength= length $allreads[0]; print "length of the reads is $liglength bp for $file \n";
	my $totalReads=@allreads;
	
	#----------- parse the file name to find out TF name and wells -------------
	$file =~ m/TF.*-(?=[^\d]{1})(.{1,15})IIIc/; my $TFname=$1; my $TFnoNum=$TFname=~s/[0-9\-L]*$//ir;
	$file =~ m/-([A-P]{1}\d{1,2})-/; my $well=$1;   #(?=[^\d]{1}) to make extration like TF105-NKX2-4IIIc correct
	$well=~ s/([A-P])0(\d)/$1$2/;  # to change A01 into A1 for SELEX
	
	#----------- find out pfm file to use from TF name -----
	my @matrix_files; my @matrix_Names;
	if (!$test)
	{	
		&pfmFromGuide($_,$TFname, \@matrix_files, \@matrix_Names) for @allGuides; # first the exact hit
		&pfmFromGuide($_,$TFnoNum, \@matrix_files, \@matrix_Names) for @allGuides; # then everything related
		
		if ($#matrix_files>19) {splice(@matrix_files,19,-1) ;splice(@matrix_Names,19,-1); } # cannot plot too many
		if ($#matrix_files== -1) {print "\n!!!!!!!!!!!!!!\n!!!!!!!!!\nno PWM found for $file\n\n"; return;}; # do not calc if no matrix found
	}
	if ($test) {@matrix_files=("as.pfm"); @matrix_Names=("As");} #for test
	
	my @matrix_Names_ori= @matrix_Names;
	for my $nameAdd (qw(r_ rc_ c_)) {push @matrix_Names, $nameAdd.$matrix_Names_ori[$_] for (0..$#matrix_Names_ori)}; #construct names for reverse, cmp, rev_cmp      
	my $Num_of_Matrix=scalar(@matrix_files);
	my (@matrices, @rc_matrices, @r_matrices, @c_matrices, @all_matrices,          @Motif_L_of_matrices, @thresholds);
	for (my $i=0;$i<$Num_of_Matrix;$i++)
	{
		$matrices[$i] = readMatrix($matrix_files[$i]);
		$c_matrices[$i] = [reverse (@{$matrices[$i]})]; # reverse fun result in cmp
	
		$rc_matrices[$i] = MOODS::Tools::reverseComplement($matrices[$i]);
		$r_matrices[$i] = [reverse (@{$rc_matrices[$i]})];
	
		$Motif_L_of_matrices[$i] = scalar(@{$matrices[$i][0]});
	}
                    #signal       #control
	@all_matrices = (@matrices, @r_matrices, @rc_matrices, @c_matrices); #join all matrices together to get faster mapping,   //@rc_matrices, @c_matrices not used here, pay attention to MapSR indices of @{$results[$i+$Num_of_Matrix]}
	@thresholds= (($p_value) x scalar(@all_matrices)); #()surronding p_value is important
	
    my @cut_values; # account for blank positions
    for (my $i=0; $i<$Num_of_Matrix;$i++) {$cut_values[$i] = $liglength-$Motif_L_of_matrices[$i]+1;}    
    
    
    #creat N countArrayRef and initialize with 0 for different PWMs
    my $countArrayRef;
    for (my $i=0; $i<$Num_of_Matrix;$i++) # fill x if odd, fill x.5 if even motif length
	{ if ($Motif_L_of_matrices[$i] % 2) { for (my $j=0; $j<$liglength; $j++) { $countArrayRef->[$i+$Num_of_Matrix*$_]->{$j}=0 for (0..(@all_matrices/$Num_of_Matrix-1))}; }
	  else  {for (my $j=0; $j<$liglength-1; $j++) { $countArrayRef->[$i+$Num_of_Matrix*$_]->{$j+0.5}=0 for (0..(@all_matrices/$Num_of_Matrix-1))};} 
	}
	
	my %results; # storage of all results
	&MapSR($countArrayRef,$combinedReads,$liglength,\@cut_values,\@all_matrices,\@thresholds,$Num_of_Matrix,\@matrix_Names,\%results);
	#&normalize($countArrayRef,$totalReads); # divide hits by totalReads
	
	use Mylib1::fileIO; my $outfilename=$well."_".&fileIO::getfile($file);
	
	&writeFile(\%results, $outputPath, $outfilename.".txt");
	#&CntArray::wtCountFile_Hash($countArrayRef,\@matrix_Names,$outputPath, $outfilename."_ori.txt", "ori");
	#&CntArray::wtCountFile_Hash($countArrayRef,\@matrix_Names,$outputPath, $outfilename."_rc.txt", "rc");
}

sub writeFile
{
	my ($results_Href, $outputPath, $outfilename)=@_;
	open(my $fh, ">", $outputPath."/data/".$outfilename) or die "cannot open output file";
	foreach my $PWM_name (keys $results_Href)
	{
		print $fh "FF_".$PWM_name."\t".(join "\t", @{$results_Href->{$PWM_name}->{ori_1st}->{oriRel}})."\n";
		print $fh "FR_".$PWM_name."\t".(join "\t", @{$results_Href->{$PWM_name}->{ori_1st}->{rcRel}})."\n";
		print $fh "RF_".$PWM_name."\t".(join "\t", @{$results_Href->{$PWM_name}->{rc_1st}->{oriRel}})."\n";
		print $fh "RR_".$PWM_name."\t".(join "\t", @{$results_Href->{$PWM_name}->{rc_1st}->{rcRel}})."\n";
	}	
	close $fh;
}


sub MapSR
{
    my ($countArrayRef,$combinedReads,$liglength,$cut_values_Ref,$all_matrices_Aref,$thresholds_Aref,$Num_of_Matrix,$matrix_Names_Aref,$results_Href)=@_;  #liglength, @matrices, @Motif_L_of_matrices should be passed if not in the same file
	my @all_matrices = @$all_matrices_Aref;
	my @thresholds= @$thresholds_Aref;
	my $seq = Bio::Seq->new(-seq  => $combinedReads, -alphabet => 'dna' );

        ## We convert the count matrix into log-odds scores in base 2 logarithm and find hits scoring
        my @results = MOODS::search(-seq => $seq, -matrices => \@all_matrices,  -thresholds => \@thresholds, -threshold_from_p => 1);

        #add SR count into countArrays of each PWM
        for (my $i=0; $i<$Num_of_Matrix;$i++)
        {
            #collect mapping hits
			my ($positions,$positions_rc,$positions_c,$positions_r); 
            {my $j = 0; $positions= [grep {!($j++ % 2)} @{$results[$i]}];                     $positions = &CntArray::getRealPosition($positions,$cut_values_Ref->[$i],$liglength);};
            {my $j = 0; $positions_rc =[grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix*2]}]; $positions_rc = &CntArray::getRealPosition($positions_rc,$cut_values_Ref->[$i],$liglength);};            
            {my $j = 0;  $positions_c =[grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix*3]}]; $positions_c = &CntArray::getRealPosition($positions_c,$cut_values_Ref->[$i],$liglength);}; 
			{my $j = 0;  $positions_r =[grep {!($j++ % 2)} @{$results[$i+$Num_of_Matrix]}];   $positions_r = &CntArray::getRealPosition($positions_r,$cut_values_Ref->[$i],$liglength);};
			
			use POSIX "fmod"; use List::Util qw(min max); my %matches;
			
			parsePos(\%matches,$positions,$liglength,"ori");
			parsePos(\%matches,$positions_rc,$liglength,"rc");
			parsePos(\%matches,$positions_r,$liglength,"r");
			parsePos(\%matches,$positions_c,$liglength,"c");
			
			# positions now start from 1
			autoRotate(\%matches,$liglength);
			
			
			# dimer spacing
			my @dimers= grep { @{$matches{$_}->{ori}||[]}+@{$matches{$_}->{rc}||[]} >1 } keys %matches;
			my $relPos= {"ori_1st"=>{"oriRel"=>[(0) x $liglength], "rcRel"=>[(0) x $liglength ]} ,
						 "rc_1st"=>{"oriRel"=>[(0) x $liglength], "rcRel"=>[(0) x $liglength]}     }; # to count relative positions
			foreach (@dimers) #!! also works for @dimers because @dimers contains the reference
			{
				# see which one is closer to the end, than calc relative pos
				my $min_ori= min (@{$matches{$_}->{ori}})||(100000); #should not omit () from the arr otherwise it will be a scalar
				my $min_rc= min (@{$matches{$_}->{rc}})||(100000);
				if ($min_ori<=$min_rc)
				{
					foreach (@{$matches{$_}->{ori}}) {$_-=$min_ori; $relPos->{ori_1st}->{oriRel}->[$_]++;}
					foreach (@{$matches{$_}->{rc}}) {$_-=$min_ori; $relPos->{ori_1st}->{rcRel}->[$_]++;}
				}else
				{
					foreach (@{$matches{$_}->{ori}}) {$_-=$min_rc; $relPos->{rc_1st}->{oriRel}->[$_]++;}
					foreach (@{$matches{$_}->{rc}}) {$_-=$min_rc; $relPos->{rc_1st}->{rcRel}->[$_]++;}
				}				
			}
			#@dimers=@matches{@dimers}; # collect ref from @matches ({ ori => ["49.5"], rc => ["51.5"] }, ...,  ...)
			$results_Href->{$matrix_Names_Aref->[$i]}=$relPos;
			
			
			#addCnt($countArrayRef->[$i],\%matches,$cut_values_Ref->[$i],$liglength,"ori");
			#addCnt($countArrayRef->[$i+$Num_of_Matrix*2],\%matches,$cut_values_Ref->[$i],$liglength,"rc");
			#addCnt($countArrayRef->[$i+$Num_of_Matrix*3],\%matches,$cut_values_Ref->[$i],$liglength,"c");
			#addCnt($countArrayRef->[$i+$Num_of_Matrix],\%matches,$cut_values_Ref->[$i],$liglength,"r");


        }
}

sub parsePos
{
	my ($matches,$positions,$liglength,$direction)=@_;
	foreach (@$positions)
	{
		my $ligNo=int($_/$liglength);
		my $actualPos=fmod($_, $liglength)+1; # 0>>1
		#my $minDistToEnd= min($actualPos-1,$liglength-$actualPos)
		$matches->{$ligNo}->{$direction}||=[];
		push @{$matches->{$ligNo}->{$direction}}, $actualPos; 
	}
}

sub autoRotate
{	# rotate if the dist to the right is smaller than dist to the left (both ori and rc)
	my ($matches,$liglength)=@_;
	foreach (keys $matches)
	{
		my $temp=$matches->{$_};
		next if ((!$matches->{$_}->{ori}) && (!$matches->{$_}->{rc}));
		my $minLeft= (min @{$matches->{$_}->{ori}}, @{$matches->{$_}->{rc}})-1;
		my $minRight= $liglength-(max @{$matches->{$_}->{ori}}, @{$matches->{$_}->{rc}});
			#print "original_ori:  ".(join "\t", @{$matches->{$_}->{ori}})."\n";
			#print "original_rc :  ".(join "\t", @{$matches->{$_}->{rc}})."\n";
		if ($minRight<$minLeft)
		{
			rotate($matches->{$_},$liglength);
			$matches->{$_}->{rotated}=1;
		}
	}
}

sub rotate
{
	my ($ligHref,$liglength)=@_;
	my $tmp= $ligHref->{ori}; $ligHref->{ori}= $ligHref->{rc}; $ligHref->{rc}= $tmp;
	   $tmp= $ligHref->{r}; $ligHref->{r}= $ligHref->{c}; $ligHref->{c}= $tmp;
	foreach my $dir ("ori","rc","r","c") {foreach (@{$ligHref->{$dir}}) {$_= $liglength-$_+1;}}
}

sub addCnt
{
    my ($countArrayRef, $matches,$cut_value,$liglength,$direction)=@_;

    foreach my $key (keys $matches)
    {
		next if (!$matches->{$key}->{$direction});
		foreach (@{$matches->{$key}->{$direction}})	{ $countArrayRef->{$_}++; }
    }  
}

sub pfmFromGuide #extract pfm path from guide
{
	my ($guidefile, $search_string, $matrix_files_Aref,$matrix_Names_Aref)=@_;
	my $string= "cat $guidefile | grep -P -i '^$search_string\[\\d-L]*\\t' | "; #some TF name like HOXB2L2 NKD2-4
	$string.=q{perl -lne '@all=split /\t/; $pfm_key="$all[2]_$all[3]_$all[4]"; @allpfm= glob("/var/www/kaz/data/pfm/shortspacek/$pfm_key*.pfm"); chomp @allpfm; print "$all[0]_$all[3]_$all[4]_$all[7]_$all[8]"."\t".$allpfm[0] if @allpfm;'}; # some like TAGTTA40NGTG_XEPAQ_NNNNTGCTGAC
	my @matrix_info_tmp=`$string`; chomp @matrix_info_tmp;
	map {my @info=split/\t/; push @$matrix_Names_Aref, $info[0]; push @$matrix_files_Aref, $info[1];} @matrix_info_tmp;
}

sub normalize
{
	my ($Aref,$totalReads)=@_;
	foreach my $Href (@$Aref)
	{
		#if (ref($_)) {&normalize($_,$totalReads) } else{$_/=$totalReads};
		foreach (keys $Href) {$Href->{$_}/=$totalReads;}
	}
}