#!/usr/bin/perl -w
# 2017-09-08  seperate online barcodes

use warnings;
use strict;
use Getopt::Long;
use File::Basename;
use Mylib1::seqFile;
use Mylib1::fileIO;
use Mylib1::Parallel::file;

my $this_programme = basename($0);
my $cmdInput=$this_programme." ".join(" ", @ARGV);
my $usage = "\n\$$this_programme -f 'FJ4.4CAP2/*.fq' -o barsep  -barLen 4  -minFrac 0.1
# separate reads according to the online barcodes 

  ## general ##
   -f 'str'    input reads files, can use wildcards like 'xxx/*.txt' or 'xxx/*'
   -o          output folder
   -h          get help
   -t int      number of threads to run (=10)
  ## specific ##
   -barLen int    lenth or barcoed at the beginning of each reads
   -minFrac       minimum fraction for a barcode to be separated
   --force        deal with file names without 'vbarIII' mark
   ";
	##### options     
	GetOptions ('f=s' => \my $fileGlob,'o=s' => \my $outputPath, 'h' => \my $helpInfo,'t=i' => \my $threads, 'barLen=i' => \my $barLen, 'minFrac=f' => \my $minFrac, 'force' => \my $force, 'forcedBar=s' => \my $forcedBar); # i:int   f:float   s:string
    # initialize
    if ($helpInfo||(!$fileGlob)) { print "\nusage: $usage\n";exit;}
    my ($name,$dir,$suffix)= fileparse($fileGlob); $outputPath||="$dir/$this_programme"; # to sepcified path || to path with seq files
    $threads||=10; $barLen||=4; $minFrac||=0.1;
	
	#output cmd info
	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
    #qx(rm -r $outputPath) if (-d $outputPath);
    qx(mkdir -p $outputPath); qx(mkdir -p $outputPath/perlcmd/);
    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd


#### get all files to process ######
my @file_ori= glob($fileGlob);
my @files = grep {(-f $_)&&($_=~ m/(txt$)|(gz$)|(fastq$)|(fq$)/)} glob($fileGlob); chomp @files;


#-----------
qx(mkdir $outputPath/tmp) if (!(-d "$outputPath/tmp"));
#&file::mProcess($threads,\&singleThread,\@files);
&file::mThread($threads,\&singleThread,\@files);

system("rm $outputPath/tmp -r");
exit;


sub singleThread    #!!!!!!!  the thing done by each thread, to be modified!!!!!!!
{
  my $file = shift;
  my $filename= &fileIO::getfile($file);
  print("\nprocessing $filename\n");
  unless ($force) {return unless $filename =~ m/^[^-]*v?bar/i;}
  
  my @allseq;
  seqFile::getallSeq(\@allseq,$file);
  my %allbar; my $sum;     my $ind= 3000< $#allseq? 3000: $#allseq;
  map {$allbar{substr($_,0,$barLen)}++; $sum++} @allseq[0..$ind];
  
  my $threshold=$sum*$minFrac; my %validBar;
  map {if($allbar{$_}>$threshold){$validBar{$_}++;}} keys %allbar;
  if ($forcedBar) { map { chomp($_); $validBar{$_}++;} split( " ",$forcedBar); }
  
  
  my %seped_reads; map {$seped_reads{$_}=[];} keys %validBar;
  map {my $bar=substr($_,0,$barLen); if(defined($validBar{$bar})){push $seped_reads{$bar},substr($_,$barLen);} } @allseq;
  
  map {
    my $currfilename=$outputPath."/".$filename=~s/v?barIII/b${_}III/ir=~s/.gz$//ir;
    open(my $fh, ">", $currfilename) or die "cannot open output file";
    print $fh join "\n", @{$seped_reads{$_}};
    close $fh;
    system("gzip -f $currfilename");
    } keys %seped_reads;
  print("\nfinish $filename\n");

}