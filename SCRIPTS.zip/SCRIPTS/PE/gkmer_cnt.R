#!/usr/bin/Rscript

# to be added: rmdup and bkcorr function

test=F

library(pacman)
pacman::p_load(optigrab)     # minimist)

usage="Usage:
  gkmer_cnt.R -f '*.gz' -k 3 -o outDir -t 10 --rmdup
  -f gz files to process
  -o output path
  -k kmerLength (x3)
  -t threads
  --rmdup remove duplicates
"
                  # cmdArgs=minimist()
                  #   outdir=cmdArgs[["o"]]
                  #   allfiles=cmdArgs[["f"]]
  cmdArgs=commandArgs()
    outdir=opt_get("o",opts = cmdArgs)
    allfiles=opt_get("f",opts = cmdArgs)
    kmerLen=as.integer(opt_get("k",opts = cmdArgs)); if(is.na(kmerLen)){kmerLen=9L}
    threads=as.integer(opt_get("t",opts = cmdArgs)); if(is.na(threads)){threads=10L}
    duprm=opt_get("rmdup", n = 0, opts = cmdArgs)
      if(test){
        allfiles= "~/Nut_zhuData/seqFiles2/FJ10tempSolVar/allreads/Adpt_Trimmed_Reads/2_Trim_adaptor_kmer/Trulig147v1III-FJ10tempSolvVar-30deg-*IIIc4*.gz"
        outdir="~/Nut_zhuData/_tmp/testkmer"
        duprm=T
        kmerLen=3
      }
                  # if (is.null(outdir) || is.null(allfiles) || length(Sys.glob(allfiles))==0) 
  if (is.na(outdir) || is.na(allfiles) || length(Sys.glob(allfiles))==0) {cat(usage); stop(call. = FALSE)}

  library(fjComm,readr)
  allfiles %<>% Sys.glob() 
      if(test)allfiles= head(allfiles,3)[1]
  system(paste0("mkdir -p ",outdir))

  fjComm::parallel(1:length(allfiles),function(x){
    print("counting for file: " %>% paste0(allfiles[x] %>% basename()))
    # kcnt=fjComm::kmerCntBit_file(file = allfiles[x],k = kmerLen,diffLen = F,collapse = T,asDf = T,all_possible_k = T,rmdup = duprm, bkfile = NA)
    kcnt=fjComm::gkmerCntBit_file(file = allfiles[x],gapNo = 2,k = kmerLen,gapMins = c(0,0),gapMaxs = c(5,5),pseudo = 5,diffLen = F,posInfo = F,rmdup = duprm, melt_result = T,all_possible_k = T)
    kcnt %<>% dplyr::filter(str_count(kmer,"G")<(3*kmerLen-2))
    kcnt %<>% arrange(desc(counts)) %>% head (100000)
    saveRDS(object =kcnt, file = paste0(outdir,"/",basename(allfiles[x]),".RDS"), compress = "gzip")
  },workers = threads)
  