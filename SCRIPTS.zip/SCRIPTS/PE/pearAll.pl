#!/usr/bin/perl -w
# 2015-06-28
# pear all files >> delete wrong length >> compress

#qx(export PERL5LIB="/wrk/data/fangjie/lib/perllib/":"/home/zhu/lib/perl5/":$PERL5LIB);
#qx(export PATH="/wrk/data/fangjie/lib/SCRIPTS/downloaded/":$PATH);


use warnings;
use strict;
use Getopt::Long;
use File::Basename;
use Mylib1::Parallel::file;
use Mylib1::seqFile;
use Mylib1::fileIO;


my $this_programme = basename($0);
my $cmdInput=$this_programme." ".join(" ", @ARGV);
my $usage = "\n\$$this_programme -f 'FJ4.4CAP2/*.gz' -o peared -keep 101
# pear all files >> delete wrong length >> compress 

  ## general ##
   -f 'str'    input reads files, can use wildcards like 'xxx/*.txt' or 'xxx/*'
   -o          output folder
   -h          get help
   -t int      number of threads to run (=10)
  ## specific ##
   -keep int   only keep reads of the following length after merge (=101 for Trulig147, 154 for Trulig200)
   -v int      minimun overlap for pearing (=5)
   -j int      threads for each pear run (=1)
   -keepAll    keep peared with all lengths
   ";
	##### options
	GetOptions ('f=s' => \my $fileGlob,'o=s' => \my $outputPath, 'h' => \my $helpInfo,'t=i' => \my $threads, 'keep=i' => \my $keep, 'v=i' => \my $minOl, 'j=i' => \my $t_pear, 'keepAll' => \my $keepAll); # i:int   f:float   s:string
    # initialize
    if ($helpInfo||(!$fileGlob)) { print "\nusage: $usage\n";exit;}
    my ($name,$dir,$suffix)= fileparse($fileGlob); $outputPath||="$dir/$this_programme"; # to sepcified path || to path with seq files
    $threads||=10; $keep||=101; $minOl||=5; $t_pear||=1;
	
	#output cmd info
	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
    qx(rm -r $outputPath) if (-d $outputPath);
    qx(mkdir -p $outputPath); qx(mkdir -p $outputPath/perlcmd/);
    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd


#### get all files to process ######
my @file_ori= glob($fileGlob);
my @files = grep {(-f $_)&&($_=~ m/(txt$)|(gz$)|(fastq$)/)} glob($fileGlob); chomp @files;


#-----------
qx(mkdir $outputPath/tmp) if (!(-d "$outputPath/tmp"));
&file::mProcess($threads,\&singleThread,\@files);
#&file::mThread($threads,\&singleThread,\@files);

system("rm $outputPath/tmp -r");
exit;


sub singleThread    #!!!!!!!  the thing done by each thread, to be modified!!!!!!!
{
  my $file = shift;
  my $filename= &fileIO::getfile($file);
  print("\npearing $filename\n");
  return unless $filename =~ m/_R1_/i;
  $filename =~ s/\.fastq\.gz//i;
  my $file_r2= $file =~ s/_R1_/_R2_/ir;
  `pear -f $file -r $file_r2 -o $outputPath/tmp/$filename -v $minOl -j $t_pear`;
  
  # keep only reads of the right length
  if (!$keepAll) {
	  my $assembled= "$outputPath/tmp/$filename.assembled.fastq";
      my $cmd= "awk 'BEGIN {OFS = \"\\n\"} {header = \$0 ; getline seq ; getline qheader ; getline qseq ; if (length(seq) == $keep)
      {print header, seq, qheader, qseq}}' < $assembled > $outputPath/$filename.peared.fq";
      #print "$cmd\n";
      system($cmd); system("gzip $outputPath/$filename.peared.fq");
  }
  else #keep all reads if keepAll
  {
    my $assembled= "$outputPath/tmp/$filename.assembled.fastq";
    system("cp -a $assembled $outputPath/$filename.peared.fq");
    system("gzip $outputPath/$filename.peared.fq");
  }
  

}