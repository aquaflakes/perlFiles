#!/usr/bin/Rscript

# end trim to rm quality < ","
# select only the correct Rnd length
# not "N" +-1 near the middle N run
# no adaptor kmers
test=F

library(pacman)
pacman::p_load(optigrab)     # minimist)

usage="Usage:
  pear_no_overlap.R -f *.gz -o outDir
  -f gz files to process
  -o output path
"
                  # cmdArgs=minimist()
                  #   outdir=cmdArgs[["o"]]
                  #   allfiles=cmdArgs[["f"]]
  cmdArgs=commandArgs()
    outdir=opt_get("o",opts = cmdArgs)
    allfiles=opt_get("f",opts = cmdArgs)
      if(test){
        allfiles= "~/Nut_zhuData/seqFiles2/FJ4.6CAPFLLin/Original_reads/170919_K00110_0141_BHJKHKBBXX_Fangjie/FJ4.6-CAPFLLin/*.gz"
        outdir="~/Nut_zhuData/seqFiles2/FJ4.6CAPFLLin/Original_reads/test"
      }
                  # if (is.null(outdir) || is.null(allfiles) || length(Sys.glob(allfiles))==0) 
  if (is.na(outdir) || is.na(allfiles) || length(Sys.glob(allfiles))==0) {cat(usage); stop(call. = FALSE)}

pacman::p_load(ShortRead, stringr, Biostrings, readr, magrittr)
  allfiles %<>% Sys.glob() %>% .[str_detect(.,"_R1_...\\.fastq\\.gz")]
      if(test)allfiles= head(allfiles,3)[1]
  system(paste0("mkdir -p ",outdir))
  
# on the same strand
widom_Left="GGCCGCTCAATTGG" %>% str_sub(1,11)
widom_Right="GTCTCCAGGCACGT" %>% reverse() %>% str_sub(1,11) %>% reverse()
N_in_middle=10

# # adaptor 14 mer
#     left_adaptor_HT="AATGATACGGCGACCACCGAGATCTACACTCTTTCCCTACACGACGCTCTTCCGATCT";
#     right_adaptor_HT=c("AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC","ATCTCGTATGCCGTCTTCTGCTTGAAAAAAAAAAAAAAAA");
#       allsubstr <- function(x, n) unique(substring(x, 1:(nchar(x) - n + 1), n:nchar(x)))
#     adaptor_str= lapply(c(left_adaptor_HT,right_adaptor_HT), function(x)allsubstr(x,14)) %>% unlist
# adaptor_str= paste0(adaptor_str,collapse = "|") %>% paste0("|GAAG.GCAC.{0,20}$","|GGAA....ACAC.{0,20}$")
adaptor_str= paste0("GAAG.GCAC.{0,20}$","|GGAA....ACAC.{0,20}$")

single <- function(read1_file)
{
  if (!str_detect(read1_file,"_R1_.{2,6}.fastq.gz$")) return
  read2_file= read1_file %>% str_replace("_R1_","_R2_")
  
  read1= readFastq(read1_file) %>% trimEnds(",")
  read2= readFastq(read2_file) %>% trimEnds(",")
  
  # determine random length
  rnd_len1= read1@sread %>% tail(1000) %>% as.character() %>% str_replace(paste0(widom_Left,".*$"),"") %>% nchar %>% table %>% .[which.max(.)] %>% names %>% as.integer()
  rnd_len2= read2@sread %>% tail(1000) %>% Biostrings::reverseComplement() %>% as.character() %>% str_replace(paste0("^.*", widom_Right),"") %>% nchar %>% table %>% .[which.max(.)] %>% names %>% as.integer()
  if(rnd_len1!=rnd_len2) stop("!!!!\n!!!!!!\n different Rnd Length in two side !!!!\n!!!!!" %>% paste0(read1_file %>% basename(), "!!!!!\n"))
    cat(paste0("processing ",basename(read1_file),"      rnd_len=",rnd_len1,"\n"))
  
  # check if same number of reads in R1 R2, and if barcode all match
  read1_ind= read1@id %>% as.character %>% str_sub(end= -16)
  read2_ind= read2@id %>% as.character %>% str_sub(end= -16)
  if(!identical(read1_ind,read2_ind) || !identical(length(read1@sread),length(read2@sread))) stop("!!!!\n!!!!!!\n PE index mismatch !!!!\n!!!!!" %>% paste0(read1_file %>% basename(), "!!!!!\n"))
  rm(read1_ind,read2_ind)
  
  read1= read1@sread %>% as.character() %>% str_replace(paste0(widom_Left,".*$"),"")
  read2= read2@sread %>% Biostrings::reverseComplement() %>% as.character() %>% str_replace(paste0("^.*", widom_Right),"")
  
  filter_reads= (nchar(read1)==rnd_len1) & (nchar(read2)==rnd_len2) & (read1 %>% str_sub(-1,-1))!="N" & (read2 %>% str_sub(1,1))!="N" 
  reads= paste0( read1[filter_reads], rep("N",N_in_middle) %>% paste0(collapse = ""), read2[filter_reads] ) %>% .[!str_detect(.,adaptor_str)]
  
    outFileName= basename(read1_file) %>% str_replace("_R1_.{2,6}.fastq.gz$","_paired.fastq")
    outfile= paste0(outdir,"/",outFileName)
  writeLines(reads, outfile)
    rm(reads)
  system(paste0("gzip -f ",outfile))
  
}

tt=lapply(allfiles,single)




