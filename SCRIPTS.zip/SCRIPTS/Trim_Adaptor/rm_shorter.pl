#!/usr/bin/perl -w
# remove shorter reads after trim_galore for read length >55bp
# output to "shorter" dir the same path as each file

use warnings;
use strict;
use Mylib1::Parallel::file;



#*** INIT ***
    use File::Basename; my $this_programme = basename($0);
    my $cmdInput=$this_programme." ".join(" ", @ARGV);
    my $usage = "\n\$$this_programme -f '*.gz' -t 25
	-len 40    can specify exact length if hope to discard all other lengths
	
   ";
	##### options
	use Getopt::Long;
	GetOptions ('f=s' => \my $fileGlob, 'o=s' => \my $outputPath, 't=i' => \our $threads, 'len=i' => \my $extLen); # i:int   f:float   s:string
    if (!$fileGlob) { print "\nusage: $usage\n";exit;}
    $threads||=10; 
	
#	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
#    qx(rm -r $outputPath) if (-d $outputPath);    qx(mkdir -p $outputPath); qx(mkdir -p $outputPath/perlcmd/);
#    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd
#	
# -----------
my @files = glob($fileGlob); chomp @files;
my @param; for (my $i=0;$i<@files;$i++) { push @param, $files[$i]; }

&file::mProcess($threads,\&singleProc,\@param); 
exit;

sub singleProc
{
	my $file=shift;
	print "processing $file \n";

	use Mylib1::seqFile; my @allreads; &seqFile::getallSeq(\@allreads,$file); chomp(@allreads);
	my $maxLenQ=qq{zcat $file |head -1000 | awk '{ if ( length > L ) { L=length} }END{ print L}'};
	my $maxLen=`$maxLenQ`; chomp ($maxLen);
	if ($extLen) { $maxLen=$extLen; }
	
	
	use Mylib1::fileIO; my $currDir=&fileIO::getdir($file);
	my $shortPath=$currDir."/short";
	
	if (!-d $shortPath) { system ("mkdir $shortPath");}
	
	
	$file=~m/[^\/]*$/;
	my $outFileName= ${^MATCH};
	use IO::Compress::Gzip qw(gzip $GzipError) ;
	my $shortzip = new IO::Compress::Gzip("$shortPath/$outFileName") or die "gzip failed: $GzipError\n";
	my $outzip= new IO::Compress::Gzip("$currDir/$outFileName-tmp") or die "gzip failed: $GzipError\n";
	
	my $allcnt=@allreads; my $rmcnt=0;
	
	LoopThroughReads:
    foreach my $seq (@allreads)
    {
		if ( (length($seq)<$maxLen) || ($extLen && length($seq)!=$maxLen) || ($seq=~ m/GAAG.GCAC.{0,20}$|GGAA....ACAC.{0,20}$/i) )
		{
			print $shortzip $seq."\n";
			$rmcnt++; next LoopThroughReads;
		}
		print $outzip $seq."\n";
    }
	
	close $outzip;
	close $shortzip;
		
	`mkdir -p $shortPath/stat` if !(-d "$shortPath/stat");    open(my $shortstat, ">>", $shortPath."/stat/Allstat.txt") or die "cannot write output stat file";
	print $shortstat $outFileName."\t"."$rmcnt reads in $allcnt total reads deleted (".$rmcnt/$allcnt*100 ."%)\n";
	close $shortstat;
	`mv $currDir/$outFileName-tmp $file`;
}





