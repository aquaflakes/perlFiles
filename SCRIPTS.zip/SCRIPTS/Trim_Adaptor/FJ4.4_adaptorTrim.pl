#!/usr/bin/perl -w

use warnings;
use strict;
use Mylib1::Parallel::file;



#*** INIT ***
    use File::Basename; my $this_programme = basename($0);
    my $cmdInput=$this_programme." ".join(" ", @ARGV);
    my $usage = "\n\$$this_programme -f '*.gz' -o Adpt_Trimmed_Reads/ -t 10 -type TruHT

  USE: to trim adaptor reads involved in TruHT lib, if PE reads should be merged  //2016-06-28
  
  ## general ##
   -f 'str' all files to be processed, META CHAR OK
   -t int   total thread No. (1 /file)
   
  ## specific ##
   -type 'str'  the type of adaptor, can be 'TruHT', 'Nex', 'smallRNA', default=TruHT
   -40Nonly  random region only has 40N, for Yin's library
   ";
	##### options
	use Getopt::Long;
	GetOptions ('f=s' => \my $fileGlob, 'o=s' => \my $outputPath, 't=i' => \our $threads, 'type=s' => \my $libtype, '40Nonly' => \my $is40N); # i:int   f:float   s:string
    if (!$fileGlob) { print "\nusage: $usage\n";exit;}
    $threads||=10;
	
	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
    #qx(rm -r $outputPath) if (-d $outputPath);
	qx(mkdir -p $outputPath); qx(mkdir -p $outputPath/perlcmd/);
    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd
	
	
#   my @files = glob($fileGlob); chomp @files;
#	my @param; for (my $i=0;$i<@files;$i++) { push @param, $files[$i]; } 

# -----------trim garole
 qx(mkdir -p $outputPath/1_Trim_garole/);  qx(mkdir -p $outputPath/2_Trim_adaptor_kmer/);
 my $length_cutoff= $is40N? 40:55; # print $length_cutoff;
 system("/wrk/data/fangjie/lib/SCRIPTS/Parallel/parallel_v1.pl -f '$fileGlob' -o $outputPath/1_Trim_garole/ -t $threads -cmd 'trim_galore -q 10 --illumina --stringency 4 --length $length_cutoff --gzip --suppress_warn -o $outputPath/1_Trim_garole/ SingleFiles'");
 qx(mkdir -p $outputPath/1_Trim_garole/stat); qx(mv $outputPath/1_Trim_garole/*report.txt $outputPath/1_Trim_garole/stat);

$fileGlob= $outputPath."/1_Trim_garole/*.gz"; 
my @files = glob($fileGlob); chomp @files;
my @param; for (my $i=0;$i<@files;$i++) { push @param, $files[$i]; }
$outputPath.="/2_Trim_adaptor_kmer/"; 
#------------

&file::mProcess($threads,\&singleProc,\@param);
#&file::mThread($threads,\&singleProc,\@param); 
qx(rm $fileGlob); 

sub singleProc
{
	my $file=shift;
	print "processing $file \n";
	
	my ($i5bar, $i7bar)=("","");
	$file=~ m/(?P<bar>[CTAG-]*)_[^\/]*$/i;
	my $bar= $1; 
	if ($is40N) {$file=~ m/(?P<bar>[CTAG-]*)_[^\/]*$/i; $bar= $_;}
	
	
	if ($bar=~m/-/) {($i7bar, $i5bar) = (split "-", $bar);}
	else {$i7bar=$bar;}
	print("i5bar: $i5bar --- i7bar: $i7bar\n");
	
	my $left_adaptor_HT="AATGATACGGCGACCACCGAGATCTACAC[i5]ACACTCTTTCCCTACACGACGCTCTTCCGATCT";
	my $right_adaptor_HT="AGATCGGAAGAGCACACGTCTGAACTCCAGTCAC[i7]ATCTCGTATGCCGTCTTCTGCTTGAAAAAAAAAAAAAAAA";
	
	my ($left_adaptor, $right_adaptor)=($left_adaptor_HT=~s/\[i5\]/$i5bar/ir, $right_adaptor_HT=~s/\[i7\]/$i7bar/ir); # use Truseq HT adaptor by default, replace index
	#print "left adaptor: $left_adaptor \n right adaptor: $right_adaptor \n";
	
	my %all_14_mer_adpt;
	for (my $i=0; $i<(length $left_adaptor)-14; $i++) {$all_14_mer_adpt{uc substr($left_adaptor,$i,14)}=1;}
	for (my $i=0; $i<(length $right_adaptor)-14; $i++) {$all_14_mer_adpt{uc substr($right_adaptor,$i,14)}=1;}
	
	use Mylib1::seqFile; my @allreads; &seqFile::getallSeq(\@allreads,$file);
	#my $maxLenQ=qq{zcat $file |head -1000 | awk '{ if ( length > L ) { L=length} }END{ print L}'};
	#my $maxLen=`$maxLenQ`; chomp ($maxLen);
	
	
	$file=~m/[^\/]*$/;
	my $outFileName= ${^MATCH};
	use IO::Compress::Gzip qw(gzip $GzipError) ; my $outzip = new IO::Compress::Gzip("$outputPath/$outFileName") or die "gzip failed: $GzipError\n";
	`mkdir -p $outputPath/deleted` if !(-d $outputPath."/deleted");    open(my $outdel, ">", $outputPath."/deleted/".$outFileName."del.txt") or die "cannot write output del file";
	my $allcnt=@allreads; my $rmcnt=0;
	
	LoopThroughReads:
    foreach my $seq (@allreads)
    {
		for (0..(length $seq)-14)
		{
			my $current_kmer=uc substr($seq,$_,14);
			 if (defined $all_14_mer_adpt{$current_kmer})
			 {
				print $outdel $seq."\n";
				$rmcnt++; next LoopThroughReads;
			 }			
		}
		print $outzip $seq."\n";
    }
	
	close $outzip;
	close $outdel;
		
	`mkdir -p $outputPath/stat` if !(-d $outputPath."/deleted");    open(my $outstat, ">>", $outputPath."/deleted/Allstat.txt") or die "cannot write output stat file";
	print $outstat $outFileName."\t"."$rmcnt reads in $allcnt total reads deleted (".$rmcnt/$allcnt*100 ."%)\n";
	close $outstat;
}





