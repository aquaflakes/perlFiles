#!/usr/bin/perl -w
# 2015-05-10


use warnings;
use strict;
use Getopt::Long;
use File::Basename;

#------- fixed global--------
our $tfclassDB="/wrk/data/fangjie/DefaultFilesforProc/all_Human_TF_classification";
#----------------------------


my $this_programme = basename($0);
my $cmdInput=$this_programme." ".join(" ", @ARGV);
my $usage = "\n\$$this_programme -g '/var/www/kaz/guide/xx.txt' -o xxx
  print TF classification given TF name

  ## general ##
   -h          get help
   -t  i       threads

  ## specific ##
   -g  s       guide file
   -o  s       output path
   ";
	##### options
	GetOptions ('h' => \my $helpInfo, 'o=s' => \my $outputPath, 'g=s' => \my $guide, 't=i' => \my $threads); # i:int   f:float   s:string
	if ($helpInfo||(!$guide)) { print "\nusage: $usage\n";exit;}
	$outputPath||="./$this_programme"; 
    $threads||=10;
	
	#output cmd info
	use File::Spec qw(rel2abs); my $currpath=File::Spec->rel2abs("./");
    qx(rm -r $outputPath) if (-d $outputPath);    qx(mkdir -p $outputPath); qx(mkdir -p $outputPath/perlcmd/);
    qx(echo ">> launching folder\n""$currpath""\n\n>> ORIGINAL CMD\n""$cmdInput""\n\n>> META CHAR EXPANDED\n"$cmdInput >$outputPath/perlcmd/perlcmd.txt); # memo input cmd
	
	
my @guidelines= `cat $guide`; chomp @guidelines;

use Mylib1::guideFile;
my $posCol= &guideFile::colIndex($guide,"pos");
my $TFCol= &guideFile::colIndex($guide,"TF");

shift @guidelines;#eliminate header
my @param= map {my @currline=split /\t/; [$currline[$TFCol],$currline[$posCol]]} @guidelines;

use Mylib1::Parallel::file;
#&file::mProcess($threads,\&singleProc,\@param);
&file::mThread ($threads,\&singleProc,\@param);

use Mylib1::fileIO; my $guide_nameonly=&fileIO::getfile($guide);
qx(cat $outputPath/*.txt > $outputPath/TFfamily_$guide_nameonly);
qx(rm $outputPath/TF_family_call*.txt);

my $file="$outputPath/TFfamily_$guide_nameonly";
&guideFile::addColFromFile($file,$guide,$outputPath,[qw(2 3)],[qw(class family)]);
exit;

sub singleProc
{
	my $param_Aref = shift;
	my ($TF,$well)= @$param_Aref;
	$TF=~ tr/\r//d;
	system("TF_classification.pl -tf $TF -well $well >$outputPath/TF_family_call$well.txt")
}
	
