#!/usr/bin/perl -w
# 2015-05-10


use warnings;
use strict;
use Getopt::Long;
use File::Basename;

#------- fixed global--------
our $tfclassDB="/wrk/data/fangjie/DefaultFilesforProc/TF_classification/all_Human_TF_classification";
our $familyOnlyDB="/wrk/data/fangjie/DefaultFilesforProc/TF_classification/all_Human_TF_classification_family";
our $classOnlyDB="/wrk/data/fangjie/DefaultFilesforProc/TF_classification/all_Human_TF_classification_class";
#----------------------------


my $this_programme = basename($0);
my $cmdInput=$this_programme." ".join(" ", @ARGV);
my $usage = "\n\$$this_programme -tf NKX1 -well A01
  print TF classification given TF name

  ## general ##
   -h          get help

  ## specific ##
   -tf s       TF name
   ";
	##### options
	GetOptions ('tf=s' => \my $tfName,'h' => \my $helpInfo, 'well=s' => \my $well); # i:int   f:float   s:string
	if ($helpInfo||(!$tfName)) { print "\nusage: $usage\n";exit;}
	$tfName=uc($tfName);

#open(my $tf, "<", $tfclassDB) or die "no tfclassDB file";
#my @allentry=<$tf>; chomp @allentry;
#close $tf;

my $family; my $class; my $tfNameOri=$tfName; my @allhits;
$tfName= $1 if $tfName=~ m/(.*?)ooo/i;
# omit TF name with <3 char, special simple TF specified here
push @allhits, "6.5.1.0.1 T (Brachyury)" if $tfName eq "T";
if ($tfName =~ m/SKOR/) {push @allhits, "5.3.0 SAND domain factors" ; $family="SKI transcriptional corepressors";} # 0 to unspecify family
push @allhits, "3.1.0 Homeo domain factors" if $tfName =~ m/LASS/; # 0 to unspecify family
push @allhits, "6.3.1.0.1 p53" if $tfName =~ m/^TP\d3/; # 0 to unspecify family


if (!@allhits&&length($tfName)>=3) {@allhits= `grep -Pi "[\\s(]"$tfName $tfclassDB `;}


print $well."\t" if $well;

# replace specific error and grep
if (!@allhits&&length($tfName)>=3)
{
	$tfName=~ s/CEBP/C\/EBP/ig;  #c/ebp in dict
	@allhits= `grep -Pi "[\\s(]"$tfName $tfclassDB`;
}

# grep with - inserted somewhere
if (!@allhits&&length($tfName)>=3)
{
	foreach my $i (0..length($tfName)-1)
	{
		last if @allhits;
		my $nameOriLocal=$tfName;
		substr($tfName,$i,0,"-");
		@allhits= `grep -Pi "[\\s(]"$tfName $tfclassDB`;
		$tfName=$nameOriLocal;
	}
}

# grep without suffix if no hits
if (!@allhits&&length($tfName)>=3)
{
	$tfName=~ s/[\.L\-\d]*$//ig;
	@allhits= `grep -Pi "[\\s(]"$tfName $tfclassDB` if length($tfName)>=3;
}

# grep only first 3 char if still no hits, upper case only
if (!@allhits && length($tfName)>=3)
{
	$tfName= substr($tfName,0,3);
	@allhits= `grep -P "[\\s(]"$tfName $tfclassDB`; 
}

if (!@allhits)
{
	print "$tfNameOri\tNA\tNA\n"; exit;
}

my $found_flag=0;


foreach (@allhits)
{
	if ($_=~m/^((\d+\.\d+)\.\d+)/ && $found_flag==0) {
		$found_flag=1;
		my $cmd= "grep -Pi '^$1\\s' $familyOnlyDB";
		$family=`$cmd` unless $family; chomp $family;
		$cmd="grep -Pi '^$2\\s' $classOnlyDB";
		$class=`$cmd`; chomp $class;
	}
}


if (!$found_flag)
{
	print "$tfNameOri\tNA\tNA\n"; exit;
}
else {print "$tfNameOri\t$class\t$family\n"};
exit;